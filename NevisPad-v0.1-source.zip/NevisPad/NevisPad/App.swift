import UIKit
import WebKit
import UniformTypeIdentifiers
import CoreText

@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions options: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        let window = UIWindow(frame: UIScreen.main.bounds)
        window.rootViewController = EditorController()
        window.makeKeyAndVisible()
        self.window = window
        return true
    }
    func applicationWillResignActive(_ application: UIApplication) {
        (window?.rootViewController as? EditorController)?.flush()
    }
}

private struct BridgeError: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

final class EditorController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate, UIDocumentPickerDelegate {
    private var webView: WKWebView!
    private let fm = FileManager.default
    private var pickerRequest: (id: String, kind: String)?
    private let maxFileBytes = 32 * 1024 * 1024
    private var webRoot: URL!
    private var documents: URL!
    private var fonts: URL!
    private var trash: URL!

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.12, green: 0.21, blue: 0.32, alpha: 1)
        do {
            let base = fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
            documents = base.appendingPathComponent("Nevis", isDirectory: true)
            fonts = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("NevisFonts", isDirectory: true)
            trash = base.appendingPathComponent("Nevis-Trash", isDirectory: true)
            for url in [documents!, fonts!, trash!] { try fm.createDirectory(at: url, withIntermediateDirectories: true) }
        } catch { showStartupError(error.localizedDescription); return }

        let config = WKWebViewConfiguration()
        config.userContentController.add(self, name: "nevis")
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = self
        webView.isOpaque = false
        webView.backgroundColor = .clear
        webView.scrollView.bounces = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
        guard let root = Bundle.main.resourceURL?.appendingPathComponent("Web"),
              fm.fileExists(atPath: root.appendingPathComponent("index.html").path) else {
            showStartupError("Editor resources are missing from this build."); return
        }
        webRoot = root
        webView.loadFileURL(root.appendingPathComponent("index.html"), allowingReadAccessTo: root)
    }

    func flush() { webView?.evaluateJavaScript("window.Nevis && window.Nevis.flush()", completionHandler: nil) }

    private func showStartupError(_ message: String) {
        let label = UILabel(frame: view.bounds.insetBy(dx: 28, dy: 50))
        label.numberOfLines = 0; label.textColor = .white; label.text = message
        view.addSubview(label)
    }

    private func documentURL(_ id: String) throws -> URL {
        guard UUID(uuidString: id) != nil else { throw BridgeError(message: "Invalid document ID.") }
        return documents.appendingPathComponent(id.lowercased() + ".nevis")
    }

    private func reply(_ id: String, value: Any = NSNull(), error: String? = nil) {
        let payload: [String: Any] = ["id": id, "value": value, "error": error as Any? ?? NSNull()]
        guard let data = try? JSONSerialization.data(withJSONObject: payload), let json = String(data: data, encoding: .utf8) else { return }
        webView.evaluateJavaScript("window.NativeReply(\(json));", completionHandler: nil)
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.frameInfo.isMainFrame,
              let source = message.frameInfo.request.url, source.isFileURL,
              source.standardizedFileURL.path.hasPrefix(webRoot.standardizedFileURL.path + "/"),
              let body = message.body as? [String: Any],
              let id = body["id"] as? String, let action = body["action"] as? String else { return }
        let args = body["args"] as? [String: Any] ?? [:]
        do {
            switch action {
            case "boot":
                reply(id, value: ["systemFonts": UIFont.familyNames.sorted(), "fonts": try readFonts()])
            case "list":
                let items = try fm.contentsOfDirectory(at: documents, includingPropertiesForKeys: nil)
                    .filter { $0.pathExtension == "nevis" }
                    .compactMap { url -> [String: Any]? in
                        guard let data = try? Data(contentsOf: url), let doc = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return nil }
                        return ["id": doc["id"] ?? "", "title": doc["title"] ?? "Untitled", "updated": doc["updated"] ?? "", "preview": doc["preview"] ?? ""]
                    }
                reply(id, value: items)
            case "load":
                let url = try documentURL(args["id"] as? String ?? "")
                let data = try Data(contentsOf: url)
                reply(id, value: try JSONSerialization.jsonObject(with: data))
            case "save":
                guard let doc = args["document"] as? [String: Any], (doc["version"] as? Int) == 1 else { throw BridgeError(message: "Unsupported document.") }
                let url = try documentURL(doc["id"] as? String ?? "")
                let data = try JSONSerialization.data(withJSONObject: doc)
                guard data.count <= maxFileBytes * 2 else { throw BridgeError(message: "Document is too large to save.") }
                if fm.fileExists(atPath: url.path), let old = try? Data(contentsOf: url) {
                    try old.write(to: url.appendingPathExtension("bak"), options: .atomic)
                }
                try data.write(to: url, options: .atomic)
                reply(id)
            case "trash":
                let url = try documentURL(args["id"] as? String ?? "")
                let target = trash.appendingPathComponent(UUID().uuidString + ".nevis")
                try fm.moveItem(at: url, to: target)
                reply(id)
            case "pick":
                guard pickerRequest == nil else { throw BridgeError(message: "A file picker is already open.") }
                let kind = args["kind"] as? String ?? "document"
                let types: [UTType]
                if kind == "image" { types = [.png, .jpeg, .gif] }
                else if kind == "font" { types = [UTType(filenameExtension: "ttf"), UTType(filenameExtension: "otf")].compactMap { $0 } }
                else { types = ["docx", "nevis", "html", "htm", "txt"].compactMap { UTType(filenameExtension: $0) } }
                let picker = UIDocumentPickerViewController(forOpeningContentTypes: types.isEmpty ? [.data] : types, asCopy: true)
                picker.allowsMultipleSelection = kind == "font"
                picker.delegate = self
                pickerRequest = (id, kind)
                present(picker, animated: true)
            case "export":
                guard let b64 = args["base64"] as? String, b64.utf8.count <= maxFileBytes * 3,
                      let data = Data(base64Encoded: b64) else { throw BridgeError(message: "Invalid export data.") }
                let name = safeFilename(args["name"] as? String ?? "Document.nevis")
                let dir = fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
                try fm.createDirectory(at: dir, withIntermediateDirectories: true)
                let url = dir.appendingPathComponent(name)
                try data.write(to: url, options: .atomic)
                share(url); reply(id)
            case "pdf", "print":
                try printDocument(id: id, args: args, isPDF: action == "pdf")
            default: throw BridgeError(message: "Unknown action.")
            }
        } catch { reply(id, error: error.localizedDescription) }
    }

    private func safeFilename(_ name: String) -> String {
        let clean = name.components(separatedBy: CharacterSet(charactersIn: "/\\:\0\n\r")).joined(separator: "_")
        return String(clean.prefix(120)).isEmpty ? "Document.nevis" : String(clean.prefix(120))
    }

    private func readFonts() throws -> [[String: Any]] {
        try fm.contentsOfDirectory(at: fonts, includingPropertiesForKeys: nil)
            .filter { $0.pathExtension == "json" }
            .compactMap { url in
                guard let data = try? Data(contentsOf: url) else { return nil }
                return (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
            }
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        if let request = pickerRequest { reply(request.id, value: []) }
        pickerRequest = nil
    }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let request = pickerRequest else { return }
        pickerRequest = nil
        do {
            var result: [[String: Any]] = []
            for url in urls.prefix(20) {
                let access = url.startAccessingSecurityScopedResource()
                defer { if access { url.stopAccessingSecurityScopedResource() } }
                let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
                guard size <= maxFileBytes else { throw BridgeError(message: "Maximum file size is 32 MB.") }
                let data = try Data(contentsOf: url)
                guard data.count <= maxFileBytes else { throw BridgeError(message: "Maximum file size is 32 MB.") }
                var item: [String: Any] = ["name": url.lastPathComponent, "base64": data.base64EncodedString()]
                if request.kind == "font" {
                    guard data.count <= 10 * 1024 * 1024,
                          ["ttf", "otf"].contains(url.pathExtension.lowercased()),
                          let descriptors = CTFontManagerCreateFontDescriptorsFromURL(url as CFURL) as? [CTFontDescriptor],
                          let descriptor = descriptors.first else { throw BridgeError(message: "Please select a valid TTF or OTF font (up to 10 MB).") }
                    let font = CTFontCreateWithFontDescriptor(descriptor, 16, nil)
                    item["family"] = CTFontCopyFamilyName(font) as String
                    item["postscript"] = CTFontCopyPostScriptName(font) as String
                    if let styleName = CTFontCopyName(font, kCTFontStyleNameKey) {
                        item["style"] = styleName as String
                    } else {
                        item["style"] = "Regular"
                    }
                    let traits = CTFontGetSymbolicTraits(font)
                    item["weight"] = traits.contains(.traitBold) ? "700" : "400"
                    item["italic"] = traits.contains(.traitItalic)
                    let filename = safeFilename((item["postscript"] as? String ?? UUID().uuidString) + ".json")
                    try JSONSerialization.data(withJSONObject: item).write(to: fonts.appendingPathComponent(filename), options: .atomic)
                }
                result.append(item)
            }
            reply(request.id, value: result)
        } catch { reply(request.id, error: error.localizedDescription) }
    }

    private func share(_ url: URL) {
        let activity = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        activity.popoverPresentationController?.sourceView = view
        activity.popoverPresentationController?.sourceRect = CGRect(x: view.bounds.midX, y: 15, width: 1, height: 1)
        present(activity, animated: true)
    }

    private func printDocument(id: String, args: [String: Any], isPDF: Bool) throws {
        let renderer = NevisPrintRenderer(settings: args)
        renderer.addPrintFormatter(webView.viewPrintFormatter(), startingAtPageAt: 0)
        if isPDF {
            let count = renderer.numberOfPages
            guard count > 0 && count <= 500 else { throw BridgeError(message: "PDF supports 1–500 pages.") }
            renderer.prepare(forDrawingPages: NSRange(location: 0, length: count))
            let pdf = UIGraphicsPDFRenderer(bounds: renderer.paperRect).pdfData { context in
                for page in 0..<count { context.beginPage(); renderer.drawPage(at: page, in: renderer.paperRect) }
            }
            let name = safeFilename(args["title"] as? String ?? "Document")
            let dir = fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
            try fm.createDirectory(at: dir, withIntermediateDirectories: true)
            let url = dir.appendingPathComponent(name + ".pdf")
            try pdf.write(to: url)
            share(url); reply(id)
        } else {
            let controller = UIPrintInteractionController.shared
            let info = UIPrintInfo(dictionary: nil)
            info.jobName = args["title"] as? String ?? "Nevis"
            info.outputType = .general
            info.orientation = (args["orientation"] as? String) == "landscape" ? .landscape : .portrait
            controller.printInfo = info
            controller.printPageRenderer = renderer
            controller.present(from: CGRect(x: view.bounds.midX, y: 15, width: 1, height: 1), in: view, animated: true) { _, _, error in
                self.reply(id, error: error?.localizedDescription)
            }
        }
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
        if url.isFileURL && url.standardizedFileURL.path.hasPrefix(webRoot.standardizedFileURL.path + "/") {
            decisionHandler(.allow)
        } else if navigationAction.navigationType == .linkActivated, ["https", "http", "mailto"].contains(url.scheme?.lowercased() ?? "") {
            UIApplication.shared.open(url); decisionHandler(.cancel)
        } else { decisionHandler(.cancel) }
    }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) { webView.reload() }
}

final class NevisPrintRenderer: UIPrintPageRenderer {
    private let paper: CGRect
    private let content: CGRect
    private let header: String
    private let footer: String
    private let pageNumbers: Bool
    init(settings: [String: Any]) {
        var width: CGFloat = settings["paper"] as? String == "Letter" ? 612 : 595.28
        var height: CGFloat = settings["paper"] as? String == "Letter" ? 792 : 841.89
        if settings["orientation"] as? String == "landscape" { swap(&width, &height) }
        let margin = CGFloat(min(108, max(28, (settings["margin"] as? Double ?? 72))))
        paper = CGRect(x: 0, y: 0, width: width, height: height)
        content = paper.insetBy(dx: margin, dy: margin)
        header = settings["header"] as? String ?? ""
        footer = settings["footer"] as? String ?? ""
        pageNumbers = settings["pageNumbers"] as? Bool ?? true
        super.init()
        headerHeight = 24; footerHeight = 24
    }
    override var paperRect: CGRect { paper }
    override var printableRect: CGRect { content }
    private func draw(_ text: String, in rect: CGRect) {
        let style = NSMutableParagraphStyle(); style.alignment = .center
        (text as NSString).draw(in: rect, withAttributes: [.font: UIFont.systemFont(ofSize: 9), .foregroundColor: UIColor.darkGray, .paragraphStyle: style])
    }
    override func drawHeaderForPage(at pageIndex: Int, in headerRect: CGRect) { draw(header, in: headerRect) }
    override func drawFooterForPage(at pageIndex: Int, in footerRect: CGRect) {
        let number = pageNumbers ? "\(pageIndex + 1) / \(numberOfPages)" : ""
        draw([footer, number].filter { !$0.isEmpty }.joined(separator: "    ·    "), in: footerRect)
    }
}
