'use strict';
window.Core = (() => {
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const uuid = () => crypto.randomUUID ? crypto.randomUUID() : '10000000-1000-4000-8000-100000000000'.replace(/[018]/g,c=>(+c ^ crypto.getRandomValues(new Uint8Array(1))[0]&15>>+c/4).toString(16));
  function base64(bytes) {
    let result = ''; const data = new Uint8Array(bytes);
    for (let i = 0; i < data.length; i += 16384) result += String.fromCharCode(...data.subarray(i, i + 16384));
    return btoa(result);
  }
  const unbase64 = (s) => Uint8Array.from(atob(s), c => c.charCodeAt(0));
  const text64 = s => base64(new TextEncoder().encode(s));
  const decode64 = s => new TextDecoder().decode(unbase64(s));
  const safeLink = s => /^(https?:\/\/|mailto:|#)/i.test(s || '') && !/[\u0000-\u0020]/.test(s) ? s : '';
  const safeImage = s => /^data:image\/(png|jpe?g|gif);base64,[a-z\d+/=\s]+$/i.test(s || '') ? s : '';
  const allowed = new Set('P DIV SPAN BR STRONG B EM I U S STRIKE SUB SUP H1 H2 H3 H4 H5 H6 UL OL LI BLOCKQUOTE PRE CODE TABLE THEAD TBODY TFOOT TR TD TH IMG A HR MARK FONT'.split(' '));
  const allowedStyles = new Set('font-family font-size font-weight font-style color background-color text-decoration text-decoration-line text-align line-height direction margin-left margin-right margin-top margin-bottom padding-left padding-right text-indent width height max-width border border-color border-width border-style border-collapse vertical-align'.split(' '));
  function sanitize(html) {
    const doc = new DOMParser().parseFromString(String(html).slice(0, 64 * 1024 * 1024), 'text/html');
    doc.querySelectorAll('script,style,iframe,object,embed,svg,math,link,meta,form,input,button,textarea,select,video,audio,source,template').forEach(e => e.remove());
    for (const el of [...doc.body.querySelectorAll('*')]) {
      if (!allowed.has(el.tagName)) { el.replaceWith(...el.childNodes); continue; }
      const attrs = [...el.attributes].map(a => [a.name, a.value]);
      const savedStyle = el.style.cssText;
      for (const a of [...el.attributes]) el.removeAttribute(a.name);
      for (const [name, value] of attrs) {
        if (name === 'dir' && /^(rtl|ltr|auto)$/.test(value)) el.dir = value;
        if (name === 'lang' && /^[a-z-]{2,12}$/i.test(value)) el.lang = value;
        if (name === 'href' && el.tagName === 'A' && safeLink(value)) el.setAttribute('href', value);
        if (name === 'src' && el.tagName === 'IMG' && safeImage(value)) el.setAttribute('src', value);
        if (['colspan','rowspan'].includes(name) && /^(?:[1-9]|[1-4]\d|50)$/.test(value)) el.setAttribute(name, value);
        if (['width','height'].includes(name) && /^\d{1,4}$/.test(value)) el.setAttribute(name, value);
        if (['title','alt'].includes(name)) el.setAttribute(name, value.slice(0, 1000));
        if (name === 'start' && /^\d{1,5}$/.test(value)) el.setAttribute(name, value);
        if (name === 'data-comment' && /^[a-f\d-]{36}$/i.test(value)) el.setAttribute(name,value);
        if (name === 'id' && /^heading-[a-f\d-]+$/.test(value)) el.id = value;
        if (name === 'class' && value.split(/\s/).includes('page-break')) el.className = 'page-break';
        if (el.tagName === 'FONT') {
          if (name === 'face') el.style.fontFamily = value;
          if (name === 'color' && /^#[\da-f]{3,8}$/i.test(value)) el.style.color = value;
          if (name === 'size' && /^[1-7]$/.test(value)) el.style.fontSize = [0,8,10,12,14,18,24,36][+value] + 'pt';
        }
      }
      const probe = doc.createElement('span'); probe.style.cssText = savedStyle;
      for (const prop of Array.from({length:probe.style.length},(_,i)=>probe.style.item(i))) {
        const val = probe.style.getPropertyValue(prop);
        if (allowedStyles.has(prop) && !/url\s*\(|expression|javascript|@import|[<>]/i.test(val)) el.style.setProperty(prop, val);
      }
      if (el.tagName === 'IMG' && !el.getAttribute('src')) el.remove();
    }
    return doc.body.innerHTML || '<p><br></p>';
  }
  const defaultSettings = {paper:'A4',orientation:'portrait',margin:60,font:'DejaVu Sans',size:12,lineHeight:1.6,direction:'rtl',header:'',footer:'',pageNumbers:true};
  function settings(value = {}) {
    return {
      paper: value.paper === 'Letter' ? 'Letter' : 'A4',
      orientation: value.orientation === 'landscape' ? 'landscape' : 'portrait',
      margin: Math.min(108, Math.max(28, Number(value.margin) || 60)),
      font: typeof value.font === 'string' ? value.font.slice(0,100) : defaultSettings.font,
      size: Math.min(96, Math.max(6, Number(value.size) || 12)),
      lineHeight: Math.min(3, Math.max(1, Number(value.lineHeight) || 1.6)),
      direction: value.direction === 'ltr' ? 'ltr' : 'rtl',
      header: String(value.header || '').slice(0, 240),footer: String(value.footer || '').slice(0,240),
      pageNumbers: value.pageNumbers !== false
    };
  }
  function validateDocument(value) {
    if (!value || value.version !== 1 || typeof value.html !== 'string') throw Error('فرمت سند معتبر نیست.');
    return {
      version: 1, id: /^[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12}$/i.test(value.id) ? value.id : uuid(),
      title: String(value.title || 'سند بدون عنوان').slice(0,100),
      html: sanitize(value.html), settings: settings(value.settings),
      comments: Array.isArray(value.comments) ? value.comments.filter(c=>c && /^[\da-f-]{36}$/i.test(c.id)).slice(0,500).map(c=>({id:c.id,text:String(c.text||'').slice(0,4000)})) : [],
      updated: new Date().toISOString(),preview: ''
    };
  }
  let dbPromise;
  function database() {
    if (!dbPromise) dbPromise = new Promise((resolve,reject) => {
      const request = indexedDB.open('nevis-v1',1);
      request.onupgradeneeded = () => { for (const name of ['documents','fonts','trash']) request.result.createObjectStore(name,{keyPath:'id'}); };
      request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error);
    });
    return dbPromise;
  }
  async function store(name, action, value) {
    const db = await database();
    return new Promise((resolve,reject) => {
      const tx = db.transaction(name, action === 'get' || action === 'getAll' ? 'readonly' : 'readwrite');
      const request = tx.objectStore(name)[action](value);
      tx.oncomplete = () => resolve(request.result); tx.onerror = () => reject(tx.error); tx.onabort = () => reject(tx.error || Error('Storage transaction aborted'));
    });
  }
  const pending = new Map();
  window.NativeReply = ({id,value,error}) => {
    const p = pending.get(id); if (!p) return;
    pending.delete(id); clearTimeout(p.timer); error ? p.reject(Error(error)) : p.resolve(value);
  };
  const isNative = !!window.webkit?.messageHandlers?.nevis;
  function request(action, args = {}) {
    if (!isNative) return browserRequest(action,args);
    return new Promise((resolve,reject) => {
      const id = uuid();
      const timer = setTimeout(() => { pending.delete(id); reject(Error('پاسخی از برنامه دریافت نشد. دوباره تلاش کن.')); }, ['pick','print'].includes(action) ? 600000 : 120000);
      pending.set(id,{resolve,reject,timer});
      window.webkit.messageHandlers.nevis.postMessage({id,action,args});
    });
  }
  async function browserRequest(action,args) {
    switch(action) {
      case 'boot': return {systemFonts: ['Arial','Helvetica','Times New Roman','Georgia','Courier New','Verdana'],fonts: await store('fonts','getAll')};
      case 'save': return store('documents','put',args.document);
      case 'list': return store('documents','getAll');
      case 'load': return store('documents','get',args.id);
      case 'trash': { const doc = await store('documents','get',args.id); await store('trash','put',doc); return store('documents','delete',args.id); }
      case 'pick': return pickBrowser(args.kind);
      case 'export': {
        const url = URL.createObjectURL(new Blob([unbase64(args.base64)]));
        const a = document.createElement('a'); a.href=url; a.download=args.name; a.click();
        setTimeout(()=>URL.revokeObjectURL(url),30000); return null;
      }
      case 'pdf': case 'print': window.print(); return null;
      default: throw Error('Unsupported action');
    }
  }
  function pickBrowser(kind) {
    return new Promise(resolve => {
      const input = document.createElement('input'); input.type='file';
      input.accept = kind === 'font' ? '.ttf,.otf' : kind === 'image' ? '.png,.jpg,.jpeg,.gif' : '.docx,.nevis,.html,.htm,.txt';
      input.multiple = kind === 'font';
      input.oncancel = () => resolve([]);
      input.onchange = async () => {
        const items=[];
        for (const file of [...input.files].slice(0,20)) {
          if (file.size > (kind === 'font' ? 10 : 32) * 1024 * 1024) { alert('فایل بیش از حد بزرگ است.'); continue; }
          const item={name:file.name,base64:base64(await file.arrayBuffer())};
          if(kind === 'font') { item.family=file.name.replace(/\.[^.]+$/,''); item.id=item.family; item.weight='400'; await store('fonts','put',item); }
          items.push(item);
        }
        resolve(items);
      };
      input.click();
    });
  }
  function plainText(html) { const d = new DOMParser().parseFromString(html,'text/html'); return d.body.textContent || ''; }
  return {$,esc,uuid,base64,unbase64,text64,decode64,safeLink,safeImage,sanitize,defaultSettings,settings,validateDocument,request,isNative,plainText};
})();
