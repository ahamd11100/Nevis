'use strict';
window.Formats = (() => {
  const {esc,sanitize,unbase64,base64,safeImage,safeLink} = Core;
  const points = (value, fallback=0) => {
    if (!value) return fallback;
    const n = parseFloat(value); if (!Number.isFinite(n)) return fallback;
    return /px$/.test(value) ? n * .75 : /cm$/.test(value) ? n * 72/2.54 : /in$/.test(value) ? n*72 : n;
  };
  function color(value, fallback) {
    if (!value || value === 'transparent') return fallback;
    const hex = value.replace('#','');
    if (/^[a-f\d]{6}$/i.test(hex)) return hex.toUpperCase();
    if (/^[a-f\d]{3}$/i.test(hex)) return [...hex].map(c=>c+c).join('').toUpperCase();
    const rgb = value.match(/^rgba?\(\s*(\d+),\s*(\d+),\s*(\d+)/);
    return rgb ? rgb.slice(1).map(n=>Math.min(255,+n).toString(16).padStart(2,'0')).join('').toUpperCase() : fallback;
  }
  function fontName(value) { return String(value || 'DejaVu Sans').split(',')[0].trim().replace(/^["']|["']$/g,'').replace(/[{};<>\\\n\r]/g,''); }

  async function exportDocx(record) {
    const d = docx, s = record.settings, numbering = [], comments = [];
    const commentIDs = new Map(), emittedComments = new Set();
    for (const c of record.comments || []) {
      const id=comments.length; commentIDs.set(c.id,id);
      comments.push({id,author:'Nevis',initials:'N',date:new Date(),children:[new d.Paragraph({bidirectional:true,children:[new d.TextRun({text:c.text,rightToLeft:true})]})]});
    }
    const root = new DOMParser().parseFromString(sanitize(record.html),'text/html').body;
    const base = {font:fontName(s.font),size:s.size*2,sizeComplexScript:s.size*2,rightToLeft:s.direction==='rtl',color:'243348'};
    function runStyle(el,inherited) {
      const out={...inherited}, st=el.style, tag=el.tagName;
      if (st.fontWeight==='normal' || (st.fontWeight && +st.fontWeight<600)) out.bold=out.boldComplexScript=false;
      if (st.fontStyle==='normal') out.italics=out.italicsComplexScript=false;
      if (['B','STRONG','TH'].includes(tag) || +st.fontWeight>=600 || st.fontWeight==='bold') out.bold=out.boldComplexScript=true;
      if (['I','EM'].includes(tag) || st.fontStyle==='italic') out.italics=out.italicsComplexScript=true;
      if (tag==='U' || st.textDecoration.includes('underline')) out.underline={};
      if (['S','STRIKE'].includes(tag) || st.textDecoration.includes('line-through')) out.strike=true;
      if (tag==='SUB') out.subScript=true;
      if (tag==='SUP') out.superScript=true;
      if (st.fontFamily || el.getAttribute('face')) out.font=fontName(st.fontFamily || el.getAttribute('face'));
      if (st.fontSize) out.size=out.sizeComplexScript=Math.round(points(st.fontSize,s.size)*2);
      if (st.color) out.color=color(st.color,out.color);
      if (st.backgroundColor && !el.hasAttribute('data-comment')) out.shading={fill:color(st.backgroundColor,'FFFFFF')};
      if (el.dir==='rtl' || st.direction==='rtl') out.rightToLeft=true;
      if (el.dir==='ltr' || st.direction==='ltr') out.rightToLeft=false;
      return out;
    }
    async function inline(nodes, inherited) {
      const out=[];
      for (const node of nodes) {
        if(node.nodeType===3) { if(node.textContent) out.push(new d.TextRun({...inherited,text:node.textContent.replace(/\u200b/g,'')})); continue; }
        if(node.nodeType!==1) continue;
        const style=runStyle(node,inherited);
        if(node.tagName==='BR') { out.push(new d.TextRun({...style,break:1})); continue; }
        if(node.tagName==='IMG') {
          const src=safeImage(node.src); if(!src) continue;
          const img = new Image(); img.src=src; try { await img.decode(); } catch { continue; }
          const maximum=(s.orientation==='landscape'?780:550)-s.margin*2;
          let width=node.style.width && !node.style.width.includes('%') ? points(node.style.width)*4/3 : (+node.getAttribute('width') || img.naturalWidth);
          width=Math.min(Math.max(width,20),maximum*4/3);
          const height=width*(img.naturalHeight/Math.max(1,img.naturalWidth));
          out.push(new d.ImageRun({type:/image\/jpe?g/.test(src)?'jpg':/image\/gif/.test(src)?'gif':'png',data:unbase64(src.split(',')[1]),transformation:{width,height},altText:{title:node.alt||'',description:node.alt||'',name:'Image'}}));
          continue;
        }
        const children=await inline(node.childNodes,style);
        if(node.tagName==='A' && safeLink(node.getAttribute('href'))) {
          const href=node.getAttribute('href');
          if(href.startsWith('#')) out.push(...children);
          else out.push(new d.ExternalHyperlink({link:href,children}));
        } else if(node.hasAttribute('data-comment') && commentIDs.has(node.dataset.comment) && !emittedComments.has(node.dataset.comment)) {
          const id=commentIDs.get(node.dataset.comment); emittedComments.add(node.dataset.comment);
          out.push(new d.CommentRangeStart(id),...children,new d.CommentRangeEnd(id),new d.CommentReference(id));
        } else out.push(...children);
      }
      return out;
    }
    async function paragraph(el, extra={}) {
      const st=el.style || {}, rtl=(el.dir || st.direction || s.direction)==='rtl';
      const heading=/^H[1-6]$/.test(el.tagName)?+el.tagName[1]:null;
      const style={...runStyle(el,base),rightToLeft:rtl};
      if(heading && !st.fontSize) { style.size=style.sizeComplexScript=[0,54,38,28,26,24,22][heading]; style.bold=style.boldComplexScript=true; style.color='244A67'; }
      return new d.Paragraph({
        children:await inline(el.childNodes,style),bidirectional:rtl,heading:heading?d.HeadingLevel['HEADING_'+heading]:undefined,
        alignment:({left:d.AlignmentType.LEFT,right:d.AlignmentType.RIGHT,center:d.AlignmentType.CENTER,justify:d.AlignmentType.JUSTIFIED})[st.textAlign] || (rtl?d.AlignmentType.RIGHT:d.AlignmentType.LEFT),
        spacing:{after:Math.round(points(st.marginBottom,8)*20),before:Math.round(points(st.marginTop,heading?14:0)*20),line:Math.round((parseFloat(st.lineHeight)||s.lineHeight)*240)},
        indent:{left:Math.round(points(st.marginLeft,0)*20),right:Math.round(points(st.marginRight,0)*20),firstLine:Math.round(points(st.textIndent,0)*20)},
        ...extra
      });
    }
    async function list(el, level=0) {
      const out=[], reference='list-'+numbering.length;
      numbering.push({reference,levels:Array.from({length:9},(_,i)=>({level:i,format:el.tagName==='OL'?d.LevelFormat.DECIMAL:d.LevelFormat.BULLET,text:el.tagName==='OL'?`%${i+1}.`:'•',start:Math.max(1,+el.getAttribute('start')||1),alignment:s.direction==='rtl'?d.AlignmentType.RIGHT:d.AlignmentType.LEFT,style:{paragraph:{indent:{left:720*(i+1),hanging:240}},run:{font:fontName(s.font)}}}))});
      for(const li of [...el.children].filter(x=>x.tagName==='LI')) {
        const copy=li.cloneNode(true); [...copy.children].filter(x=>['UL','OL'].includes(x.tagName)).forEach(x=>x.remove());
        if(copy.firstElementChild?.tagName==='P') {
          out.push(await paragraph(copy.firstElementChild,{numbering:{reference,level:Math.min(8,level)}}));
          const remainder=[...copy.childNodes].filter(x=>x!==copy.firstElementChild); if(remainder.length) out.push(...await blocks(remainder));
        } else out.push(await paragraph(copy,{numbering:{reference,level:Math.min(8,level)}}));
        for(const nested of [...li.children].filter(x=>['UL','OL'].includes(x.tagName))) out.push(...await list(nested,level+1));
      }
      return out;
    }
    async function table(el) {
      const rows=[];
      for(const row of [...el.rows]) {
        const cells=[];
        for(const cell of row.cells) {
          let content=await blocks(cell.childNodes);
          if(!content.length || !(content[content.length-1] instanceof d.Paragraph)) content.push(new d.Paragraph(''));
          cells.push(new d.TableCell({children:content,columnSpan:cell.colSpan,rowSpan:cell.rowSpan,shading:cell.tagName==='TH'?{fill:'ECF2F7'}:cell.style.backgroundColor?{fill:color(cell.style.backgroundColor,'FFFFFF')}:undefined,margins:{top:100,bottom:100,left:100,right:100}}));
        }
        if(cells.length) rows.push(new d.TableRow({children:cells,tableHeader:[...row.cells].every(c=>c.tagName==='TH')}));
      }
      if(!rows.length) return new d.Paragraph('');
      return new d.Table({rows,width:{size:100,type:d.WidthType.PERCENTAGE},visuallyRightToLeft:s.direction==='rtl'});
    }
    async function blocks(nodes) {
      const out=[]; let loose=[];
      async function flush(){if(!loose.length)return; const p=document.createElement('p');for(const n of loose)p.append(n.cloneNode(true));loose=[];out.push(await paragraph(p));}
      for(const el of nodes) {
        if(el.nodeType===3 && !el.textContent.trim()) { if(loose.length)loose.push(el);continue; }
        if(el.nodeType!==1 || ['SPAN','B','STRONG','I','EM','U','S','SUB','SUP','A','IMG','BR','FONT','MARK','CODE'].includes(el.tagName)){loose.push(el);continue;}
        await flush();
        if(el.tagName==='TABLE')out.push(await table(el));
        else if(['UL','OL'].includes(el.tagName))out.push(...await list(el));
        else if(el.tagName==='HR')out.push(el.classList.contains('page-break')?new d.Paragraph({children:[new d.PageBreak()]}):new d.Paragraph({border:{bottom:{style:d.BorderStyle.SINGLE,color:'A0ADBA',size:6}}}));
        else if(['DIV','BLOCKQUOTE'].includes(el.tagName) && [...el.children].some(c=>/^(P|DIV|H[1-6]|TABLE|UL|OL)$/.test(c.tagName)))out.push(...await blocks(el.childNodes));
        else out.push(await paragraph(el));
      }
      await flush();return out;
    }
    const content=await blocks(root.childNodes);
    const footerRuns=[new d.TextRun({text:s.footer || '',size:18,rightToLeft:s.direction==='rtl'})];
    if(s.pageNumbers)footerRuns.push(new d.TextRun({text:s.footer?'    ·    ':'',size:18}),new d.TextRun({children:[d.PageNumber.CURRENT,' / ',d.PageNumber.TOTAL_PAGES],size:18}));
    const file=new d.Document({title:record.title,creator:'Nevis',description:'Created in Nevis for iPad',styles:{default:{document:{run:base,paragraph:{bidirectional:s.direction==='rtl',spacing:{line:Math.round(s.lineHeight*240),after:160}}}}},numbering:{config:numbering},comments:comments.length?{children:comments}:undefined,sections:[{
      properties:{page:{size:{width:s.paper==='Letter'?12240:11906,height:s.paper==='Letter'?15840:16838,orientation:s.orientation==='landscape'?d.PageOrientation.LANDSCAPE:d.PageOrientation.PORTRAIT},margin:{top:s.margin*20,bottom:s.margin*20,left:s.margin*20,right:s.margin*20,header:400,footer:400}}},
      headers:s.header?{default:new d.Header({children:[new d.Paragraph({alignment:d.AlignmentType.CENTER,children:[new d.TextRun({text:s.header,size:18,rightToLeft:s.direction==='rtl'})]})]})}:undefined,
      footers:{default:new d.Footer({children:[new d.Paragraph({alignment:d.AlignmentType.CENTER,children:footerRuns})]})},children:content.length?content:[new d.Paragraph('')]
    }]});
    return d.Packer.toBase64String(file);
  }

  const W='http://schemas.openxmlformats.org/wordprocessingml/2006/main', R='http://schemas.openxmlformats.org/officeDocument/2006/relationships';
  const kids=(e,name)=>e?[...e.children].filter(n=>n.localName===name):[];
  const child=(e,name)=>kids(e,name)[0];
  const all=(e,name)=>e?[...e.getElementsByTagNameNS(W,name)]:[];
  const attr=(e,name='val')=>e?.getAttributeNS(W,name) || e?.getAttribute('w:'+name) || '';
  const val=(e,name)=>attr(child(e,name));
  const enabled=(e,name)=>!!child(e,name) && !['0','false','off'].includes(val(e,name));
  const xml=s=>{if(/<!DOCTYPE|<!ENTITY/i.test(s))throw Error('XML غیرمجاز');const d=new DOMParser().parseFromString(s,'application/xml');if(d.getElementsByTagName('parsererror').length)throw Error('ساختار XML سند خراب است.');return d;};
  async function importDocx(bytes) {
    const zip=await JSZip.loadAsync(bytes), names=Object.keys(zip.files);
    if(names.length>4000)throw Error('این سند بیش از حد پیچیده است.');
    if(!zip.file('word/document.xml'))throw Error('فایل DOCX معتبر نیست یا رمزگذاری شده است.');
    let budget=80*1024*1024;
    async function read(path, mode='string') {
      const file=zip.file(path);if(!file)return '';
      return new Promise((resolve,reject)=>{
        const chunks=[];let size=0,stopped=false;
        const stream=file.internalStream('uint8array');
        stream.on('data',chunk=>{if(stopped)return;size+=chunk.length;budget-=chunk.length;if(budget<0 || size>32*1024*1024){stopped=true;stream.pause();reject(Error('حجم بازشدهٔ سند بیش از حد مجاز است.'));return;}chunks.push(chunk);});
        stream.on('error',reject);stream.on('end',()=>{if(stopped)return;const data=new Uint8Array(size);let offset=0;for(const c of chunks){data.set(c,offset);offset+=c.length;}resolve(mode==='bytes'?data:new TextDecoder().decode(data));});stream.resume();
      });
    }
    const documentXML=xml(await read('word/document.xml'));
    const relText=await read('word/_rels/document.xml.rels'), rels=new Map();
    if(relText)for(const rel of [...xml(relText).getElementsByTagName('Relationship')])rels.set(rel.getAttribute('Id'),{target:rel.getAttribute('Target'),external:rel.getAttribute('TargetMode')==='External'});
    const warnings=new Set(['ورود DOCX یک تبدیل تقریبی است؛ نسخهٔ اصلی فایل دست‌نخورده می‌ماند.']);
    const stylesText=await read('word/styles.xml'), styles=new Map();let defaultR=null;
    if(stylesText){const st=xml(stylesText);for(const s of all(st,'style'))styles.set(attr(s,'styleId'),s);defaultR=all(st,'rPrDefault')[0]?.firstElementChild;}
    const numText=await read('word/numbering.xml'), numbers=new Map(), numCount=new Map();
    if(numText){const nd=xml(numText),abstract=new Map(all(nd,'abstractNum').map(n=>[attr(n,'abstractNumId'),n]));for(const n of all(nd,'num'))numbers.set(attr(n,'numId'),abstract.get(val(n,'abstractNumId')));}
    const commentsText=await read('word/comments.xml'), commentMap=new Map(), comments=[];
    if(commentsText)for(const c of all(xml(commentsText),'comment')){const id=Core.uuid(),text=all(c,'t').map(n=>n.textContent).join(' ');commentMap.set(attr(c,'id'),id);comments.push({id,text});}
    function styleChain(id,seen=new Set()){if(!id||seen.has(id)||seen.size>20)return [];seen.add(id);const st=styles.get(id);return st?[...styleChain(val(st,'basedOn'),seen),st]:[];}
    function runCSS(rp){if(!rp)return '';const a=[];
      if(enabled(rp,'b')||enabled(rp,'bCs'))a.push('font-weight:bold');
      if(enabled(rp,'i')||enabled(rp,'iCs'))a.push('font-style:italic');
      const decoration=[];if(child(rp,'u')&&!['none','0'].includes(val(rp,'u')))decoration.push('underline');if(enabled(rp,'strike')||enabled(rp,'dstrike'))decoration.push('line-through');if(decoration.length)a.push('text-decoration:'+decoration.join(' '));
      const sz=+(val(rp,'sz')||val(rp,'szCs'));if(sz>=12&&sz<=384)a.push(`font-size:${sz/2}pt`);
      const rf=child(rp,'rFonts'),font=attr(rf,'cs')||attr(rf,'ascii')||attr(rf,'hAnsi');if(font)a.push(`font-family:${font.replace(/[;"'<>]/g,'')}`);
      const c=val(rp,'color');if(/^[a-f\d]{6}$/i.test(c))a.push('color:#'+c);
      let bg=attr(child(rp,'shd'),'fill');const hl=val(rp,'highlight');if(hl&&/^[a-z]+$/i.test(hl))a.push('background-color:'+hl);if(/^[a-f\d]{6}$/i.test(bg))a.push('background-color:#'+bg);
      if(enabled(rp,'rtl'))a.push('direction:rtl');return a.join(';');
    }
    function paragraphCSS(pp){if(!pp)return '';const a=[];const alignment=val(pp,'jc');if(alignment)a.push('text-align:'+({both:'justify',start:'start',end:'end'}[alignment]||alignment));const sp=child(pp,'spacing');for(const [k,css]of [['before','margin-top'],['after','margin-bottom']]){const n=+attr(sp,k);if(n)a.push(`${css}:${n/20}pt`);}const line=+attr(sp,'line');if(line&&(!attr(sp,'lineRule')||attr(sp,'lineRule')==='auto'))a.push('line-height:'+line/240);const ind=child(pp,'ind');for(const [k,css]of [['left','margin-left'],['right','margin-right'],['firstLine','text-indent']]){const n=+attr(ind,k);if(n)a.push(`${css}:${n/20}pt`);}return a.join(';');}
    async function drawing(node){const blip=node.getElementsByTagNameNS('http://schemas.openxmlformats.org/drawingml/2006/main','blip')[0];const id=blip?.getAttributeNS(R,'embed');const rel=rels.get(id);if(!rel||rel.external){warnings.add('تصاویر خارجی وارد نشدند.');return '';}
      const raw=rel.target.replace(/^\//,'');const path=raw.startsWith('word/')?raw:'word/'+raw;
      if(!/^word\/media\/[\w. -]+$/i.test(path)||!/^.*\.(png|jpe?g|gif)$/i.test(path)){warnings.add('تصاویر با قالب غیر از PNG، JPEG و GIF وارد نشدند.');return '';}
      const data=await read(path,'bytes');if(!data)return '';const type=/\.jpe?g$/i.test(path)?'jpeg':/\.gif$/i.test(path)?'gif':'png';
      const ext=node.getElementsByTagNameNS('http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing','extent')[0];const width=Math.min(1800,Math.max(10,Math.round(+(ext?.getAttribute('cx')||2857500)/9525)));
      return `<img src="data:image/${type};base64,${base64(data)}" width="${width}" alt="">`;
    }
    async function runs(parent, inherited='', active={id:null}){let out='';for(const n of parent.children){
      if(n.localName==='commentRangeStart'){active.id=commentMap.get(attr(n,'id'))||null;continue;}
      if(n.localName==='commentRangeEnd'){active.id=null;continue;}
      if(n.localName==='r'){
        const rp=child(n,'rPr');let text='';for(const x of n.children){
          if(x.localName==='t')text+=esc(x.textContent);
          if(x.localName==='tab')text+='&#9;';
          if(x.localName==='br')text+=attr(x,'type')==='page'?'<hr class="page-break">':'<br>';
          if(x.localName==='drawing')text+=await drawing(x);
          if(['footnoteReference','endnoteReference','pict','object'].includes(x.localName))warnings.add('پانویس‌ها، اشیای تعبیه‌شده و برخی تصاویر قدیمی پشتیبانی نمی‌شوند.');
        }
        const vertical=val(rp,'vertAlign');if(vertical==='superscript')text='<sup>'+text+'</sup>';if(vertical==='subscript')text='<sub>'+text+'</sub>';
        const css=inherited+';'+runCSS(rp);if(css.replace(/;/g,''))text=`<span style="${esc(css)}">${text}</span>`;
        if(active.id)text=`<span data-comment="${active.id}">${text}</span>`;out+=text;
      }else if(n.localName==='hyperlink'){const rel=rels.get(n.getAttributeNS(R,'id')),href=rel?.external?safeLink(rel.target):'';const text=await runs(n,inherited,active);out+=href?`<a href="${esc(href)}">${text}</a>`:text;}
      else if(['ins','sdt','sdtContent','smartTag','fldSimple'].includes(n.localName)){if(n.localName==='ins')warnings.add('تغییرات رهگیری‌شده به متن نهایی تبدیل شدند.');out+=await runs(n,inherited,active);}
      else if(n.localName==='del')warnings.add('تغییرات رهگیری‌شده به متن نهایی تبدیل شدند.');
      else if(n.localName==='oMath'||n.localName==='oMathPara')warnings.add('فرمول‌های حرفه‌ای Word وارد نمی‌شوند.');
    }return out;}
    async function p(node){const pp=child(node,'pPr'), chain=styleChain(val(pp,'pStyle'));
      const inherited=[runCSS(defaultR),...chain.map(s=>runCSS(child(s,'rPr')))].join(';');
      const css=[...chain.map(s=>paragraphCSS(child(s,'pPr'))),paragraphCSS(pp)].join(';');
      const heading=(val(pp,'pStyle')+' '+chain.map(s=>val(s,'name')).join(' ')).match(/heading\s*([1-6])/i);
      const tag=heading?'h'+heading[1]:'p';const bidiProperties=[...chain.map(s=>child(s,'pPr')),pp].filter(p=>child(p,'bidi'));const rtl=bidiProperties.length?enabled(bidiProperties[bidiProperties.length-1],'bidi'):false;
      const text=await runs(node,inherited);let result=`<${tag} dir="${rtl?'rtl':'ltr'}" style="${esc(css)}">${text||'<br>'}</${tag}>`;
      const num=child(pp,'numPr')||chain.map(s=>child(child(s,'pPr'),'numPr')).find(Boolean);
      if(num&&val(num,'numId')!=='0'){const id=val(num,'numId'),level=+val(num,'ilvl')||0,n=kids(numbers.get(id),'lvl').find(x=>+attr(x,'ilvl')===level);const bullet=val(n,'numFmt')==='bullet';const key=id+':'+level;const count=numCount.get(key)||+(val(n,'start')||1);numCount.set(key,count+1);result=`<${bullet?'ul':'ol'} ${bullet?'':`start="${count}"`}><li>${result}</li></${bullet?'ul':'ol'}>`;if(level>0)warnings.add('فهرست‌های چندسطحی ممکن است نیاز به تنظیم دوباره داشته باشند.');}
      if(enabled(pp,'pageBreakBefore'))result='<hr class="page-break">'+result;return result;
    }
    async function table(node){let out='<table>';const rowElements=[],activeColumns=new Map();
      for(const row of kids(node,'tr')){const tr=document.createElement('tr');let col=0;
        for(const cell of kids(row,'tc')){const cp=child(cell,'tcPr'),span=Math.min(50,Math.max(1,+val(cp,'gridSpan')||1)),merge=child(cp,'vMerge');
          if(merge&&attr(merge)!=='restart'&&activeColumns.has(col)){const previous=activeColumns.get(col);previous.rowSpan+=1;col+=span;continue;}
          const td=document.createElement(enabled(child(row,'trPr'),'tblHeader')?'th':'td');td.colSpan=span;td.innerHTML=await convertBlocks(cell);const bg=attr(child(cp,'shd'),'fill');if(/^[a-f\d]{6}$/i.test(bg))td.style.backgroundColor='#'+bg;tr.append(td);
          if(merge&&attr(merge)==='restart')activeColumns.set(col,td);else activeColumns.delete(col);col+=span;
        }rowElements.push(tr);
      }out+=rowElements.map(tr=>tr.outerHTML).join('');return out+'</table><p><br></p>';}
    async function convertBlocks(parent){let out='';for(const n of parent.children){if(n.localName==='p')out+=await p(n);else if(n.localName==='tbl')out+=await table(n);else if(['sdt','sdtContent'].includes(n.localName))out+=await convertBlocks(n);}return out;}
    const body=all(documentXML,'body')[0], section=all(documentXML,'sectPr').pop(), pg=child(section,'pgSz'), margin=child(section,'pgMar');
    const imported=Core.settings({direction:all(documentXML,'bidi').length?'rtl':'ltr',paper:Math.abs(Math.min(+attr(pg,'w'),+attr(pg,'h'))-12240)<30?'Letter':'A4',orientation:attr(pg,'orient')==='landscape'?'landscape':'portrait',margin:+attr(margin,'left')/20||60,pageNumbers:false});
    for(const kind of ['header','footer']){const ref=child(section,kind+'Reference');const rel=rels.get(ref?.getAttributeNS(R,'id'));if(!rel||rel.external)continue;const target=rel.target.replace(/^\//,'');const path=target.startsWith('word/')?target:'word/'+target;if(!/^word\/(header|footer)[\w-]*\.xml$/.test(path))continue;const data=await read(path);if(data){const x=xml(data);imported[kind]=all(x,'t').map(n=>n.textContent).join(' ').slice(0,240);if(/\bPAGE\b/.test(data))imported.pageNumbers=true;}}
    if(all(documentXML,'sectPr').length>1 || all(documentXML,'cols').some(c=>+attr(c,'num')>1))warnings.add('بخش‌بندی و ستون‌های چندگانه به یک بخش تبدیل شدند.');
    const html=sanitize(await convertBlocks(body));
    return {html,settings:imported,comments,warnings:[...warnings]};
  }
  function exportHTML(record) {
    const s=record.settings;
    return `<!doctype html><html lang="${s.direction==='rtl'?'fa':'en'}" dir="${s.direction}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(record.title)}</title><style>body{max-width:900px;margin:40px auto;padding:24px;font-family:${esc(fontName(s.font))},sans-serif;font-size:${s.size}pt;line-height:${s.lineHeight}}table{border-collapse:collapse;width:100%}td,th{border:1px solid #a0adba;padding:8px}img{max-width:100%;height:auto}.page-break{break-after:page;border:0}h1,h2,h3{break-after:avoid}a{color:#256f9c}</style></head><body>${sanitize(record.html)}</body></html>`;
  }
  return {exportDocx,importDocx,exportHTML};
})();
