# Implementation and validation

Nevis 0.1 is an experimental iPad document editor, not a fork of Microsoft Word. It contains implementation code rather than placeholder controls. The UI is Persian; document content can be mixed Persian and English.

## Runtime

- UIKit application delegate and a local WKWebView, minimum iPadOS 16.
- No private APIs, JIT, Apple ID handling, backend, remote editor or runtime CDN.
- All editor assets, two redistributable fonts and the actual DOCX/ZIP libraries are bundled as the `Web` folder reference.
- The UIKit bridge accepts messages only from the local main frame. Non-file navigation is cancelled except user-activated HTTP(S)/mailto links.
- Imported HTML is reduced to an allowlist, font/image payloads are local, and document CSS cannot load external URLs. The content security policy blocks network requests and inline JavaScript.
- The editor uses WebKit contenteditable and a limited set of deprecated `execCommand` editing APIs. That is a deliberate first-version compatibility tradeoff; no claim is made that this is a modern replacement for a mature document layout engine. Selection preservation, manual operations and a bounded snapshot undo stack are implemented above it. IME commits are recorded after composition ends.

## Native storage

JSON documents are written atomically in Documents/Nevis. A `.bak` of the previous saved version is retained. UUID validation prevents path traversal in document IDs. A serial JavaScript save chain preserves ordering and only reports saved when the corresponding native write has completed. Data is also flushed on visibility changes and application deactivation, on a best-effort basis.

Trash moves preserve the original document for manual recovery. Font metadata and base64 font bytes persist in Application Support/NevisFonts. CoreText identifies a font family and basic bold/italic style. Browser preview uses IndexedDB instead of native files; it is not the native persistence test.

## Conversion

DOCX export walks a sanitized HTML DOM into docx.js paragraphs, runs, lists, tables, image runs, simple comments and one section. It sets complex-script properties for RTL text. PDF/print uses WKWebView's print formatter and UIPrintPageRenderer, with paper size, margin, header/footer and page-number settings.

DOCX import uses JSZip and XML DOM parsing, without executing document content. A decompressed-byte budget applies while entries are read. The importer resolves common paragraph/run styles, simple numbering, raster images, basic tables and merges, comment text and simple header/footer text. It intentionally does not provide a lossless Office Open XML round trip.

Known conversion limitations include theme fonts/colors, numbering overrides, advanced list nesting, exact line spacing, mixed section page sizes, fields, anchored shapes, vertical text, VML, SmartArt, embedded spreadsheets, formula objects, footnotes/endnotes, professional revision history and layout fidelity. Unsupported content may be omitted or flattened. Always retain the original DOCX. Simple comments may lose their exact range across advanced imported structures. Imported repeated comment spans and multi-paragraph ranges are simplified on export.

The editor is a continuous paper-width surface. It does not paginate while typing. The on-screen header/footer are previews; PDF repeats native header/footer strings on pages. The PDF renderer and DOCX layout engines may wrap differently. Custom font bytes are not embedded in DOCX or `.nevis` backups.

## Build and checks

The primary workflow generates an Xcode project with XcodeGen, compiles Release for a physical iPad with code signing disabled, and packages `Payload/NevisPad.app`. No signing secret is required. A sideloading application must sign the IPA later.

`docs/Build-Nevis-from-ZIP.yml` provides an alternative for uploading only the source ZIP through an iPad browser. It uses the same tests and build commands after extraction.

Executed locally when preparing this source:

- JavaScript syntax checks for application, conversion, bridge and test scripts.
- Static checks for unique element IDs, wired actions, local resources, metadata, fonts and vendor checksums.
- Actual bundled-library DOCX generation and ZIP inspection with Persian content, table and explicit page break.
- YAML/XML/archive structure checks.

Included but not executed in the authoring environment:

- Playwright Chromium and WebKit interaction tests: RTL input, selection preservation for toolbar formatting, undo/redo, saved document reload, DOCX export/import with comments and tables, HTML sanitization, document isolation, iPad landscape/portrait screenshots.
- Xcode compilation on a macOS runner.
- Physical iPad keyboard, Files pickers, fonts, share sheet and multipage PDF review.

The authoring environment had no macOS/Xcode or installed browser, and browser download was denied by its network policy. Passing local checks must not be described as a passing iPad build. The GitHub workflow requires editor tests to pass before packaging an IPA.

After the first successful Actions build, check these native paths on a real iPad: type Persian with an external and software keyboard; background/reopen the app; import two font weights; import a DOCX containing an image; share a `.nevis` backup; export a two-page PDF with a table near a page boundary. These are release validation gaps, not functionality intentionally omitted from the code.
