#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
app_path="build/Build/Products/Release-iphoneos/NevisPad.app"
test -d "$app_path"
test -f "$app_path/NevisPad"
test -f "$app_path/Web/index.html"
test -f "$app_path/Web/vendor/docx.js"
mkdir -p dist
stage_dir="$(mktemp -d)"
trap 'rm -rf "$stage_dir"' EXIT
mkdir -p "$stage_dir/Payload"
ditto "$app_path" "$stage_dir/Payload/NevisPad.app"
ditto -c -k --keepParent "$stage_dir/Payload" dist/Nevis-unsigned.ipa
unzip -t dist/Nevis-unsigned.ipa
echo 'IPA created. Import this file into your sideloading tool to sign and install it.'
