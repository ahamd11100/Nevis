#!/usr/bin/env python3
"""Check paths and metadata that commonly break a sideload build."""
import hashlib
import json
import plistlib
import re
from collections import Counter
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / 'NevisPad/Web'
class Page(HTMLParser):
    def __init__(self):
        super().__init__(); self.ids=[]; self.paths=[]
    def handle_starttag(self, tag, attrs):
        attrs=dict(attrs)
        if 'id' in attrs: self.ids.append(attrs['id'])
        if tag=='script' and attrs.get('src'): self.paths.append(attrs['src'])
        if tag=='link' and attrs.get('href'): self.paths.append(attrs['href'])

p=Page(); p.feed((WEB/'index.html').read_text())
assert not [k for k,v in Counter(p.ids).items() if v>1], 'Duplicate HTML IDs'
for path in p.paths: assert (WEB/path).is_file(), path
source=(WEB/'app.js').read_text()
dynamic={'findText','replaceText','findNext','replaceOne','replaceAll','findStatus'}
for name in re.findall(r"\$\('([^']+)'\)",source):
    assert name in p.ids or name in dynamic, f'Missing element: {name}'
actions=set(re.findall(r'data-action="([^"]+)"',(WEB/'index.html').read_text()))
for name in actions:
    assert re.search(r'\b'+re.escape(name)+r'\s*:',source) or re.search(r'function\s+'+re.escape(name)+r'\(',source), f'Missing action: {name}'
info=plistlib.loads((ROOT/'NevisPad/Info.plist').read_bytes())
assert info['CFBundlePackageType']=='APPL'
assert len(info['UISupportedInterfaceOrientations~ipad'])==4
assert info['UIFileSharingEnabled']
icons=json.loads((ROOT/'NevisPad/Assets.xcassets/AppIcon.appiconset/Contents.json').read_text())
for i in icons['images']: assert (ROOT/'NevisPad/Assets.xcassets/AppIcon.appiconset'/i['filename']).is_file()
manifest=json.loads((ROOT/'licenses/vendor-manifest.json').read_text())
for item in manifest:
    data=(ROOT/item['path']).read_bytes()
    assert hashlib.sha256(data).hexdigest()==item['sha256'], f'Vendor checksum mismatch: {item["path"]}'
assert 'CODE_SIGNING_ALLOWED=NO' in (ROOT/'.github/workflows/build-ipa.yml').read_text()
print('PASS: HTML wiring, offline resources, font/vendor hashes, app metadata and build workflow.')
