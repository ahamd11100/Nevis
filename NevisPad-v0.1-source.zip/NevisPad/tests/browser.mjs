import {chromium, webkit} from 'playwright';
import {createServer} from 'node:http';
import {readFile, mkdir, writeFile} from 'node:fs/promises';
import {resolve, extname} from 'node:path';
import assert from 'node:assert/strict';

const root=resolve('NevisPad/Web');
const types={'.html':'text/html','.js':'text/javascript','.css':'text/css','.ttf':'font/ttf'};
const server=createServer(async(req,res)=>{
  try {const path=resolve(root,'.'+decodeURIComponent(req.url.split('?')[0]==='/'?'/index.html':req.url.split('?')[0]));if(!path.startsWith(root+'/')){res.writeHead(403);res.end();return;}res.setHeader('Content-Type',types[extname(path)]||'application/octet-stream');res.end(await readFile(path));}
  catch {res.writeHead(404);res.end();}
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
await mkdir('test-results',{recursive:true});
const results=[];
let failure=false;
try {
  for(const [name,engine] of [['chromium',chromium],['webkit',webkit]]) {
    const browser=await engine.launch({headless:true});
    try {
      const context=await browser.newContext({viewport:{width:1194,height:834},deviceScaleFactor:1,hasTouch:true});
      const page=await context.newPage(); const errors=[];
      page.on('pageerror',e=>errors.push(e.message));
      await page.goto(`http://127.0.0.1:${server.address().port}/`);
      await page.waitForFunction(()=>window.Nevis?.getDocument()?.title && document.getElementById('saveState').textContent.includes('✓'));
      await page.screenshot({path:`test-results/${name}-ipad.png`});
      assert.equal(await page.locator('#editor table').count(),1,'Welcome table renders');
      await page.evaluate(()=>Nevis.actions.new());
      await page.locator('#editor').click();
      await page.keyboard.insertText('سلام دنیا — Nevis editor');
      await page.evaluate(()=>Nevis.flush());
      const savedID=await page.evaluate(()=>Nevis.getDocument().id);
      await page.reload();
      await page.waitForFunction(id=>window.Nevis?.getDocument()?.id===id,savedID);
      assert.match(await page.locator('#editor').innerText(),/سلام دنیا/,'Autosave survives reload');
      await page.evaluate(()=>{const e=document.getElementById('editor');const r=document.createRange();r.selectNodeContents(e.firstElementChild);const s=getSelection();s.removeAllRanges();s.addRange(r);e.focus();});
      await page.locator('[data-command="bold"]').click();
      assert.match(await page.locator('#editor').innerHTML(),/font-weight:\s*(bold|700)|<b>|<strong>/,'Toolbar keeps selection');
      await page.locator('#undo').click();
      assert.doesNotMatch(await page.locator('#editor').innerHTML(),/font-weight:\s*(bold|700)|<b>|<strong>/,'Undo applies');
      await page.locator('#redo').click();
      assert.match(await page.locator('#editor').innerHTML(),/font-weight:\s*(bold|700)|<b>|<strong>/,'Redo applies');
      const converted=await page.evaluate(async()=>{
        const id=Core.uuid();
        const fixture={version:1,id:Core.uuid(),title:'Round trip',settings:{...Core.defaultSettings,header:'سرصفحه',footer:'پابرگ'},comments:[{id,text:'یادداشت آزمایشی'}],html:`<h1>عنوان فارسی</h1><p dir="rtl"><strong>متن ضخیم</strong> <span style="font-size:18pt;color:#cc3300" data-comment="${id}">متن اندازه‌دار</span></p><ol start="3"><li>سه</li><li>چهار</li></ol><table><tr><th>نام</th><th>مقدار</th></tr><tr><td>R</td><td>100 Ω</td></tr></table><hr class="page-break"><p>صفحهٔ بعد</p>`};
        const b64=await Formats.exportDocx(fixture);
        const zip=await JSZip.loadAsync(Core.unbase64(b64));
        const xml=await zip.file('word/document.xml').async('string');
        const imported=await Formats.importDocx(Core.unbase64(b64));
        return {xml,html:imported.html,comments:imported.comments,header:imported.settings.header};
      });
      assert.match(converted.xml,/<w:bidi/);assert.match(converted.xml,/<w:tbl>/);assert.match(converted.xml,/<w:commentRangeStart/);assert.match(converted.xml,/w:type="page"/);
      assert.match(converted.html,/عنوان فارسی/);assert.match(converted.html,/<table/);assert.match(converted.html,/18pt/);assert.equal(converted.comments.length,1);assert.equal(converted.header,'سرصفحه');
      const safe=await page.evaluate(()=>Core.sanitize('<p onclick="alert(1)">OK</p><script>alert(1)</script><a href="javascript:alert(1)">Bad</a><img src="https://remote/image.png"><iframe src="https://remote/"></iframe><span style="background-image:url(https://remote/)">Text</span>'));
      assert.doesNotMatch(safe,/script|onclick|iframe|https:\/\/remote|javascript:/,'Unsafe imported HTML stripped');
      await page.evaluate(()=>Nevis.actions.new());
      await page.locator('#editor').click();await page.keyboard.insertText('سند دوم');await page.evaluate(()=>Nevis.flush());
      const stored=await page.evaluate(()=>Core.request('load',{id:localStorage.getItem('last-document')}));assert.match(stored.html,/سند دوم/);
      const previous=await page.evaluate(id=>Core.request('load',{id}),savedID);assert.match(previous.html,/سلام دنیا/,'Switching documents does not overwrite old content');
      await page.setViewportSize({width:744,height:1133});
      await page.screenshot({path:`test-results/${name}-portrait.png`});
      assert.deepEqual(errors,[],'No uncaught browser errors');
      results.push({engine:name,status:'passed',checks:['editor boot','RTL typing','autosave and reload','selection formatting','undo/redo','DOCX export/import','comments and header','import sanitization','multiple documents']});
      await context.close();
    } catch(error){failure=true;results.push({engine:name,status:'failed',error:error.stack});console.error(name,error);}
    finally{await browser.close();}
  }
} finally {server.close();await writeFile('test-results/report.json',JSON.stringify(results,null,2));}
if(failure)process.exitCode=1;else console.log('PASS: Chromium and WebKit integration checks.');
