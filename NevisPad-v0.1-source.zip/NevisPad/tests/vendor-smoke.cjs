// Runs without npm: confirms the actual bundled libraries create a valid DOCX ZIP.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const JSZip = require('../NevisPad/Web/vendor/jszip.js');
const context = { TextEncoder, TextDecoder, Uint8Array, ArrayBuffer, DataView, Buffer, Blob, atob, btoa, setTimeout, clearTimeout, console };
vm.createContext(context);
vm.runInContext(fs.readFileSync('NevisPad/Web/vendor/docx.js', 'utf8'), context);
(async () => {
  const d = context.docx;
  const file = new d.Document({sections:[{children:[
    new d.Paragraph({bidirectional:true,children:[new d.TextRun({text:'آزمایش فارسی Nevis',bold:true,boldComplexScript:true,rightToLeft:true,font:'DejaVu Sans'})]}),
    new d.Table({rows:[new d.TableRow({children:[new d.TableCell({children:[new d.Paragraph('Cell 1')]}),new d.TableCell({children:[new d.Paragraph('Cell 2')]})]})]}),
    new d.Paragraph({children:[new d.PageBreak()]})
  ]}]});
  const encoded = await d.Packer.toBase64String(file);
  const zip = await JSZip.loadAsync(Buffer.from(encoded,'base64'));
  const xml = await zip.file('word/document.xml').async('string');
  assert.match(xml,/آزمایش فارسی Nevis/); assert.match(xml,/<w:bidi/); assert.match(xml,/<w:tbl>/); assert.match(xml,/w:type="page"/);
  assert.ok(zip.file('[Content_Types].xml')); assert.ok(zip.file('_rels/.rels'));
  console.log('PASS: bundled DOCX and ZIP libraries, Persian, table and page break.');
})().catch(e=>{console.error(e);process.exitCode=1;});
